# Scanned doc

In perimeter.
