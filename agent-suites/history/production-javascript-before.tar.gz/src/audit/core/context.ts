import { findRepoRoot, loadConfig } from "../config/load.ts";
import type { SkeletonConfig } from "../config/types.ts";
import type { PolicyFile } from "../policies/types.ts";
import {
	collectDocMetaPaths,
	collectScanFiles,
	filterDocMetaPaths,
	filterToPaths,
	includeExplicitMarkdownPaths,
} from "./collect.ts";
import type { FileSource } from "./repo-files.ts";
import { buildSkillIndex, listSkillMarkdownPaths, type SkillIndex } from "./skill-roots.ts";
import type { SsotForm } from "./ssot.ts";
import { collectSsotEntries, type SsotFileEntry } from "./ssot-collect.ts";

export interface AuditContext {
	root: string;
	config: SkeletonConfig;
	files: string[];
	docMetaPaths: string[];
	/** Opt-in SSOT-bearing files (catalog membership). */
	ssotEntries: SsotFileEntry[];
	ssotErrors: Array<{
		path: string;
		kind: "dual" | "malformed";
		detail: string;
		forms?: SsotForm[];
	}>;
	/**
	 * @deprecated Prefer ssotEntries — kept empty for plugin type stability during transition.
	 */
	registryPaths: string[];
	/** @deprecated Always false — hand registry removed. */
	registryHasTableHeader: boolean;
	skillIndex: SkillIndex;
	/**
	 * Foreign (synced) skill slugs — same as `skillIndex.foreignSlugs`.
	 * Used by doc-meta to skip consumer-side git-date freshness on upstream bodies.
	 */
	lockedSkillSlugs: Set<string>;
	/** Compiled prose policies from plugins (empty when no plugins / no policy globs). */
	policies: PolicyFile[];
	/** Read document and dependency bytes from the worktree or the git index. */
	fileSource?: FileSource;
}

export interface AuditOptions {
	root?: string;
	changed?: boolean;
	paths?: string[];
	policies?: PolicyFile[];
	/**
	 * Union skill-tree markdown (SKILL.md + references/**) into the corpus even when
	 * `scan.exclude` dropped them. Used by bare `audit skills` so skill-scoped prose
	 * matches path-scoped / validate `--base` prove.
	 */
	includeExcludedSkillTrees?: boolean;
	/** When `index`, review-proof and coverage reads use `git show :path`. */
	fileSource?: FileSource;
}

export function createContext(options: AuditOptions = {}): AuditContext {
	const root = options.root ?? findRepoRoot();
	const config = loadConfig(root);
	const skillIndex = buildSkillIndex(root, config.skillOwnership);
	let files = collectScanFiles(config, root, skillIndex);

	if (options.includeExcludedSkillTrees) {
		files = includeExplicitMarkdownPaths(files, listSkillMarkdownPaths(root, skillIndex), root);
	}

	if (options.paths && options.paths.length > 0) {
		files = includeExplicitMarkdownPaths(files, options.paths, root);
		files = filterToPaths(files, options.paths, root);
	}

	const ssot = collectSsotEntries(files, root);
	const ssotPaths = ssot.entries.map((e) => e.path);
	const allDocMetaPaths = collectDocMetaPaths({
		config,
		root,
		registryPaths: ssotPaths,
		skillIndex,
	});

	return {
		root,
		config,
		files,
		docMetaPaths:
			options.paths && options.paths.length > 0
				? filterDocMetaPaths(allDocMetaPaths, options.paths, skillIndex)
				: allDocMetaPaths,
		ssotEntries: ssot.entries,
		ssotErrors: ssot.errors,
		registryPaths: [],
		registryHasTableHeader: false,
		skillIndex,
		lockedSkillSlugs: new Set(skillIndex.foreignSlugs),
		policies: options.policies ?? [],
		fileSource: options.fileSource,
	};
}
